# Mobile Studio — protótipo 0.1

Este é um projeto inicial independente inspirado na categoria de ferramentas e no fluxo visual do APK de referência enviado pelo usuário. Não reutiliza código, marca ou recursos proprietários extraídos do APK.

## O que já funciona neste protótipo
- Viewport 3D com câmera por toque, grade e iluminação (Three.js carregado por CDN).
- Criar Parts e Models de demonstração.
- Explorer com seleção e remoção de objetos.
- Properties para nome, posição e cor.
- Editor de texto para scripts Luau (edição, ainda sem execução).
- Painel Terrain demonstrativo (ações representadas por blocos).
- Exportar/importar projeto `.msproj` em JSON.

## Ainda não implementado
- Engine Roblox real e execução de Luau com APIs Roblox.
- Serialização/importação fiel de `.rbxl` / `.rbxm`.
- Terrain voxel real.
- Publicação Roblox. O botão é apenas um aviso; ainda não existe integração Open Cloud nem tela segura para configurar credenciais.

## Gerar APK sem computador (GitHub Actions)

É possível compilar este projeto na nuvem usando o GitHub Actions. O APK será gerado pelo GitHub; este ZIP continua sendo o código-fonte, não um instalador.

1. No GitHub, crie um repositório novo.
2. Envie o arquivo `MobileStudio_Project_v0.1.zip` para a raiz do repositório.
3. No repositório, toque em **Add file → Create new file**.
4. No nome do arquivo, digite `.github/workflows/build-apk.yml`.
5. Cole o workflow abaixo e salve com **Commit changes**.
6. Abra a aba **Actions**, selecione **Build Mobile Studio APK** e toque em **Run workflow**.
7. Quando terminar, abra a execução concluída e baixe o artefato `MobileStudio-debug-apk`. Dentro dele estará `app-debug.apk`.

```yaml
name: Build Mobile Studio APK
on:
  workflow_dispatch:
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - name: Checkout repository
        uses: actions/checkout@v4
      - name: Unpack project ZIP
        run: |
          mkdir project
          unzip MobileStudio_Project_v0.1.zip -d project
      - name: Set up Java
        uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: '17'
      - name: Set up Gradle
        uses: gradle/actions/setup-gradle@v4
        with:
          gradle-version: '8.7'
      - name: Set up Android SDK
        uses: android-actions/setup-android@v3
      - name: Install Android SDK packages
        run: sdkmanager 'platforms;android-35' 'build-tools;35.0.0'
      - name: Build debug APK
        run: gradle -p project assembleDebug
      - name: Upload APK
        uses: actions/upload-artifact@v4
        with:
          name: MobileStudio-debug-apk
          path: project/app/build/outputs/apk/debug/app-debug.apk
          if-no-files-found: error
```

Observação: o GitHub pode exigir que você confirme seu e-mail e habilite Actions no repositório. Não publique senhas nem chaves de API no repositório.

## Gerar APK com computador
Abra esta pasta no Android Studio, sincronize o Gradle e gere um APK de debug. Requer Android SDK 35 e JDK 17. Este ambiente de criação não possui Android SDK/Gradle instalados, portanto o APK não foi compilado aqui.

## Segurança
Não coloque senha Roblox no app. Para a publicação futura, usar Open Cloud com chave de API de escopo mínimo, armazenada com segurança e nunca incluída no código-fonte.
